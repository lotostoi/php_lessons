<?php
function api_auth_vk() {
    return [
        'page'=>'auth-vk'
    ];
} 