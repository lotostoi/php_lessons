<?php
function api_auth() {
    return [
        'page'=>'auth'
    ];
} 