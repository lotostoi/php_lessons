<?php
 function api_catalog() {
    return [
        'page'=>'catalog'
    ];
} 