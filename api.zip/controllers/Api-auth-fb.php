<?php
function api_auth_fb() {
    return [
        'page'=>'auth-fb'
    ];
} 