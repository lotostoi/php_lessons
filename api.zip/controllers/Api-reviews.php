<?php
function api_filter() {
    return [
        'page'=>'filters'
    ];
} 