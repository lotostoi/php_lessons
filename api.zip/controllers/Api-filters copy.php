<?php
function api_reviews() {
    return [
        'page'=>'reviews'
    ];
} 