<?php

/* $path = file_get_contents('https://graph.facebook.com/3435303603361672/picture?width=300'); */

file_put_contents('img-usersss', 'https://graph.facebook.com/3435303603361672/picture?width=300'); 