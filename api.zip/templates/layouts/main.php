<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Document</title>
    <link href="/src/css/maine03ef1172b3ef65bb4ce.css" rel="stylesheet">
</head>
</head>


<body>
    <?= $header ?>
    <?= $content ?>
    <?= $footer ?>
    <script src="/src/js/main.bundle.js"></script>
</body>

</html>