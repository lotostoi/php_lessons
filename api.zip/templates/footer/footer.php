<footer class="footer wrapper" id="contacts">
        <div class="footer__filter">
            <div class="footer__cont">
                <h3 class="footer__title">Мои контакты_</h3>
                <div class="footer__body">
                    <div class="footer__contacts">
                        <div class="field"><span class="field__title">Телефон:</span> <span class="field__content">89242521756</span></div>
                        <div class="field"><span class="field__title">Телеграм:</span> <span class="field__content">89242521756</span></div>
                        <div class="field"><span class="field__title">What's app:</span> <span class="field__content">89242521756</span></div>
                        <div class="field"><span class="field__title">Discord:</span> <span class="field__content">89242521756</span></div>
                        <div class="social"><a href="#">Facebook</a> <a href="#">Instagram</a> <a href="#">GitHub</a></div>
                    </div>
                    <div class="footer__form">
                        <h4>Или просто напишите мне_</h4>
                        <input name="name" placeholder="Ваше имя" /> <input type="email" name="email" placeholder="Вашь e-mail" />
                        <textarea name="message" cols="30" rows="10" placeholder="Текст сообщения"></textarea> <button>Отправить</button>
                    </div>
                </div>
                <p>© <?= date('Y') ?> Александр Плотников. Все права защищены</p>
            </div>
        </div>
    </footer>